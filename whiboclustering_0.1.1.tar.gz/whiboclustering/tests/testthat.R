library(testthat)
library(whiboclustering)

test_check("whiboclustering")
